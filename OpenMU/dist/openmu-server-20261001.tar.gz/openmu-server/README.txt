OpenMU Private Server - Quick Start
====================================

1. Copy this folder onto a Linux server (Ubuntu/Debian/CentOS/Rocky recommended).
2. Run the one-command installer (it installs Docker if needed):

     sudo bash install.sh --public-address <SERVER_PUBLIC_IPV4>

   Optional player web portal:  --portal-domain mu.example.com
   Custom admin webpage port:   --web-port 8080

3. The stack builds and starts. Credentials are generated and stored in
   deploy/all-in-one/.env (chmod 600).

Connect:
  Game client: <SERVER_PUBLIC_IPV4>:44406 (TCP)
  Admin panel: http://127.0.0.1:80/   (loopback only; use an SSH tunnel)

Stop (database is preserved):
     bash deploy/quick-start.sh --down

Notes:
  - Open firewall/security-group TCP ports: 443 (portal, optional),
    44405 (legacy) and 44406 (game).
  - The admin panel stays loopback-only for safety.
